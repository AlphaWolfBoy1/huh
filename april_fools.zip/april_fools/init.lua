-- april fools in argentina is here 28th december why not make some pranks to your friends with this mod


minetest.register_node("april_fools:fakestone_with_diamond", {
	description = ("FakeDiamond Ore"),
	tiles = {"default_stone.png^default_mineral_diamond.png"},
	groups = {cracky = 1},
	drop = "default:dirt",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("april_fools:fake_stone" , {
		description = ("Trap Stone"),
		drawtype = "glasslike_framed",
		tiles = {"default_stone.png"},
		walkable = false,
		groups = {cracky = 3},
		paramtype = "light",
		is_ground_content = false,
		sounds = sound_stone,
		no_stairs = true,
})

minetest.register_node("april_fools:fail", {
	description = "Rip",
  visual_scale = 2.0,
	tiles = {"fail.png"},
    drawtype = "torchlike",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5, dig_immediate = 3},
})


minetest.register_node("april_fools:firefox", {
	description = ("Fake Firefox"),
	tiles = {"default128.png"},
	groups = {cracky = 4},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("april_fools:fake_torch", {
	description = "apriltorch",
  visual_scale = 2.0,
	tiles = {"default_torch_on_floor.png"},
    drawtype = "torchlike",
    sunlight_propagates = true,
    paramtype = "light",
    groups = {plastic = 5, dig_immediate = 3},
})


minetest.register_node("april_fools:youdied", {
	description = ("dead"),
	tiles = {"dead.png"},
	groups = {cracky = 1},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("april_fools:banned", {
	description = ("banned"),
	tiles = {"ban.png"},
	groups = {cracky = 1},
	sounds = default.node_sound_stone_defaults(),
})

